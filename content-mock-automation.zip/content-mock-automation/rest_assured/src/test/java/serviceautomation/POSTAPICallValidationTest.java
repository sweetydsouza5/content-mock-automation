package serviceautomation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import constants.ServiceConstants;
import dto.getdto.Data;
import dto.getdto.Human;
import dto.getdto.GetResponseBody;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;

import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import javax.validation.ValidatorFactory;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.io.File;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;

public class POSTAPICallValidationTest{
  private static final Logger logger=LoggerFactory.getLogger(POSTAPICallValidationTest.class);
  
  @BeforeEach
  public void setUp(){
    RestAssured.baseURI=ServiceConstants.BASE_URL;
    RestAssured.basePath=ServiceConstants.BASE_PATH;
  }
  
  @Test
  @DisplayName("Verify that response code 404 is returned when empty request body is given")
  public void given_PostURIWithInvalidRequestBody_when_PostAPICall_then_ResponseCode404(){
    RestAssured.given().contentType(ContentType.JSON).body("{ }").post(ServiceConstants.POST_PATH).then().statusCode(404);
  }
  
  @Test
  @DisplayName("Verify that valid POST api call returns 200 response code")
  public void given_PostURIWithValidRequestBody_when_PostAPICall_then_Response200(){
    File requestBody=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\PostReq");
    RestAssured.given().contentType(ContentType.JSON).body(requestBody)
      .post(ServiceConstants.POST_PATH).then().statusCode(200);
  }
  
  @Test
  @DisplayName("Verify that valid POST API call response body has header content type as json")
                public void given_PostURIWithValidRequestBody_when_PostAPICall_then_ResponseContentTypeIsAppJson(){
                  
                  File requestBody=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\PostReq");
                  RestAssured.given().contentType(ContentType.JSON).body(requestBody)
                    .post(ServiceConstants.POST_PATH).then().
                    header("Content-Type","application/json");
                  }
                
               
               
               @Test
               @DisplayName("Verify that valid POST API call response body has content type as json")
               public void given_PostURIWithValidRequestBody_when_PostAPICall_theb_ResponseContentTypeIsJson(){
                 File requestBody=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\PostReq");
                 
                 RestAssured.given().contentType(ContentType.JSON).body(requestBody)
                   .post(ServiceConstants.POST_PATH).then().
                   contentType(ContentType.JSON);
                 }
               
               
  @Test
  @DisplayName("Verify that valid POST API call response body has valid data")
  public void given_PostURIWithValidRequestBody_when_PostAPICall_then_ResponseBodyIsExpected(){
    File requestBody=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\PostReq");
    RestAssured.given().contentType(ContentType.JSON).body(requestBody)
      .post(ServiceConstants.POST_PATH).then()
      .assertThat()
      .body("data.hero.name",equalTo("R2-D2"))
      .body("data.hero.friends.name",hasItems("Luke Skywalker","Han Solo","Leia Organa"));
  }
  
  @AfterEach
  public void tearDown(){
    RestAssured.reset();
  }
}
