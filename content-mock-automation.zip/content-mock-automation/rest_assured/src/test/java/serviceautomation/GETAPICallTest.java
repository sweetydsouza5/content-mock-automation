package serviceautomation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import constants.ServiceConstants;
import dto.getdto.Data;
import dto.getdto.Human;
import dto.getdto.GetResponseBody;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import javax.validation.ValidatorFactory;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class GETAPICallTest{
private static final Logger logger=LoggerFactory.getLogger(GETAPICallTest.class);

  @BeforeEach
  public void setUp(){
    RestAssured.baseURI=ServiceConstants.BASE_URL;
    RestAssured.basePath=ServiceConstants.BASE_PATH;
  }
  
  @AfterEach
  public void tearDown(){
    RestAssured.reset();
  }
  
  @Test
  @DisplayName("Verify the GET request gives 200 response code")
  public void given_ValidGetURI_when_GetCall_then_Receive200ResponseCode(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertNotNull(response);
    
    Assertions.assertEquals(200,response.getStatusCode(),"Response code is not 200");
    
  }
  
  @Test
  @DisplayName("Verify that response status is OK")
  public void given_ValidGetURI_when_GetCall_then_ReceiveOKResponseStatus(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertNotNull(response);
    String[] contents=response.getStatusLine().split(" ");
    Assertions.assertEquals("OK",contents[contents.length-1]);
    
  }
  
  @Test
  @DisplayName("Verify that response header content type is application/json")
  public void given_ValidGetURI_when_GetCall_then_ResponseHeader(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertNotNull(response);
    Assertions.assertEquals("application/json",response.getContentType());
    Assertions.assertEquals("application/json",response.getHeader("Content-type"));
  }
  
  @Test
  @DisplayName("Verify that response has a body")
  public void given_ValidGetURI_when_GetCall_then_ResponseHasBody(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertNotNull(response);
    Assertions.assertNotNull(response.getBody());
  }
  
  @Test
  @DisplayName("Verify that response body is not empty")
  public void given_ValidgetURI_when_GetCall_then_ResponseBodyNotEmpty(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertNotNull(response);
    Assertions.assertNotNull(response.getBody());
    Assertions.assertFalse(response.getBody().asString().isEmpty());
    Assertions.assertFalse(response.getBody().asString().isBlank());
  }
  
  @Test
  @DisplayName("Verify that the get API call takes less than a second")
  public void given_ValidGetURI_when_GetCall_then_ExpectedResponseTime(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    Assertions.assertTrue(response.getTimeIn(TimeUnit.MILLISECONDS)<1000,"Get call takes >1s");
  }
  
  @Test
  @DisplayName("Verify that the get API call gives valid response body")
  public void given_ValidGetURI_when_GetCall_then_ValidateResponseBody(){
    Response response=RestAssured.given().get(ServiceConstants.GET_PATH);
    ObjectMapper objectMapper=new ObjectMapper();
    try{
      GetResponseBody responseBody=objectMapper.readValue(response.getBody().asString(),GetResponseBody.class);
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator=factory.getValidator();
      Set<ConstraintViolation<GetResponseBody>> responseBodyViolationSet=validator.validate(responseBody);
      Set<ConstraintViolation<Data>> dataViolationSet=validator.validate(responseBody.getData());
      Set<ConstraintViolation<Human>> humanViolationSet=validator.validate(responseBody.getData().getHuman());
      for(ConstraintViolation<GetResponseBody> violation:responseBodyViolationSet){
        logger.info("Error Message(Response Body) : "+violation.getMessage());
      }
      for(ConstraintViolation<Data> violation:dataViolationSet){
        logger.info("Error Message(Data Body) : "+violation.getMessage());
      }
      for(ConstraintViolation<Human> violation:humanViolationSet){
        logger.info("Error Message(Human Body) : "+violation.getMessage());
      }
      Assertions.assertTrue(responseBodyViolationSet.isEmpty(),"Response Body is invalid");
      Assertions.assertTrue(dataViolationSet.isEmpty(),"Response Body.Data is invalid");
      Assertions.assertTrue(humanViolationSet.isEmpty(),"Response Body.Data.Human is invalid");
      
    }catch(JsonProcessingException e){
      Assertions.fail("Response Body is not as expected");
    }
  }

}
