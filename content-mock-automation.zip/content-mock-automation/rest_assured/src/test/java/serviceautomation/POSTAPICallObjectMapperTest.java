package serviceautomation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import constants.ServiceConstants;
import dto.postdto.PostResponseBody;
import dto.postdto.Data;
import dto.postdto.Hero;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;


import org.junit.jupiter.api.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import javax.validation.ValidatorFactory;
import java.util.Set;
import java.io.File;


public class POSTAPICallObjectMapperTest{
private static final Logger logger=LoggerFactory.getLogger(POSTAPICallObjectMapperTest.class);

  File requestBody=new File(System.getProperty("user.dir")+"\\src\\test\\resources\\PostReq.json");
ObjectMapper objectMapper=new ObjectMapper();

@BeforeEach
public void setUp(){
RestAssured.baseURI=ServiceConstants.BASE_URL;
RestAssured.basePath=ServiceConstants.BASE_PATH;
}
@AfterEach
public void tearDown(){
RestAssured.reset();
}

@Test
  @DisplayName("Verify that valid post request gives 200 response code")
  public void given_ValidPOSTURI_when_POSTCall_then_ResponseStatus200(){
    Response response=RestAssured.given().accept(io.restassured.http.ContentType.MULTIPART)
      .contentType(ContentType.JSON).body(requestBody).post(ServiceConstants.POST_PATH);
    String[] contents =response.getStatusLine().split(" ");
    Assertions.assertEquals(200,response.getStatusCode(),"Response code is not 200");
  }
  
  @Test
  @DisplayName("Verify that valid post request returns OK response status")
  public void given_ValidPOSTURI_when_POSTCall_then_ResponseCodeOK(){
    Response response=RestAssured.given().accept(io.restassured.http.ContentType.MULTIPART)
      .contentType(ContentType.JSON).body(requestBody).post(ServiceConstants.POST_PATH);
    String[] contents =response.getStatusLine().split(" ");
    Assertions.assertEquals("OK",contents[contents.length-1]);
  }
  
  @Test
  @DisplayName("Verify the response body for valid POST call")
  public void given_ValidPOSTURI_when_POSTCall_then_ResponseBodyIsValid(){
    Response response=RestAssured.given().accept(io.restassured.http.ContentType.MULTIPART)
      .contentType(ContentType.JSON).body(requestBody).post(ServiceConstants.POST_PATH);
    try{
      
      
      PostResponseBody responseBody=objectMapper.readValue(response.getBody().asString(),PostResponseBody.class);
      
      ValidatorFactory factory=Validation.buildDefaultValidatorFactory();
      Validator validator=factory.getValidator();
      Set<ConstraintViolation<PostResponseBody>> responseBodyViolationSet=validator.validate(responseBody);
      Set<ConstraintViolation<Data>> dataViolationSet=validator.validate(responseBody.getData());
      Set<ConstraintViolation<Hero>> heroViolationSet=validator.validate(responseBody.getData().getHero());
      
      for( ConstraintViolation<PostResponseBody> violation:responseBodyViolationSet){
        logger.info("Error Message(Response Body) : "+violation.getMessage());
      }
      for( ConstraintViolation<Data> violation:dataViolationSet){
        logger.info("Error Message(Response.Data Body) : "+violation.getMessage());
      }
      for( ConstraintViolation<Hero> violation:heroViolationSet){
        logger.info("Error Message(Response.Data.Hero Body) : "+violation.getMessage());
      }
      
      Assertions.assertTrue(responseBodyViolationSet.isEmpty(),"Response Body is invalid");
      Assertions.assertTrue(dataViolationSet.isEmpty(),"Response Body is invalid");
      Assertions.assertTrue(heroViolationSet.isEmpty(),"Response Body is invalid");
      
    }catch(JsonProcessingException e){
      logger.error("Json Processing failed for "+response.getBody().asString());
      Assertions.fail("Response body is not as expected");
    }
  }

}
