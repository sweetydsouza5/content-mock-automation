package dto.postdto;

import javax.validation.constraints.NotNull;

public class Data{
  @NotNull(message="Data in Post response must contain Hero")
  private Hero hero;
  
  public Hero getHero(){
    return hero;
    }
  public void setHero(Hero hero){
    this.hero=hero;
    }
  }

