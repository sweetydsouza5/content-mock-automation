package dto.postdto;

import javax.validation.constraints.NotBlank;

public class Friend{
  @NotBlank(message="Friend in Post response must have name value")
  private String name;
  
  public String getName(){
    return name;
    }
  public void setName(String name){
    this.name=name;
    }
  }
