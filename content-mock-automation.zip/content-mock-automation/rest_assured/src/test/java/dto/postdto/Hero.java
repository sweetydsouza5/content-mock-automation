package dto.postdto;

import javax.validation.constraints.NotNull;
import java.util.List;

public class Hero{
  
  @NotNull(message="Hero name cannot be null")
  private String name;
  
  private List<Friend> friends;
  
  public void setName(String name){
    this.name=name;
    }
  
  public String getName(){
    return name;
    }
  
  public List<Friend> getFriends(){
    return friends;
    }
  
  public void setFriends(List<Friend> friends){
    this.friends=friends;
    }
  }
