package dto.postdto;

import javax.validation.constraints.NotNull;

 public class PostResponseBody{
   
   @NotNull(message="Post response body must conatin data")
   private Data data;
   
   public void setData(Data data){
     this.data=data;
     }
   
   public Data getData(){
     return data;}
   }
