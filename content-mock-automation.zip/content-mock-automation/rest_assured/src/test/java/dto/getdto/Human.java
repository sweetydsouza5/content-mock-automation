package dto.getdto;

import javax.validation.constraints.NotBlank;

import javax.validation.constraints.NotNull;

import javax.validation.constraints.Pattern;

public class Human{
  @NotBlank(message="Name cannot be null")
  private String name;
  
  @NotNull(message="Height cannot ne null")
  @Pattern(regexp="^[0-9]+[.][0-9]+$",message="Height is not in valid format")
  private String height;
  
  public void setHeight(String height){
    this.height=height;
  }
  
  public String getHeight(){
    return height;
  }
  
  public void setName(String name){
    this.name=name;
  }
  
  public String getName()
    {
      return name;
    }
}
