package dto.getdto;

import javax.validation.constraints.NotNull;

public class GetResponseBody{
  @NotNull
  private Data data;
  
  public Data getData(){
    return data;
  }
  public void setData(Data data){
    this.data=data;
  }
}
