package dto.getdto;

import javax.validation.constraints.NotNull;

/**
*DTO class for Data
*
**/
public class Data{
  @NotNull(message="Human details should be present in data")
  private Human human;
  
  public Human getHuman(){
    return human;
  }
  
  public void setHuman(Human human){
    this.human=human;
  }
}
