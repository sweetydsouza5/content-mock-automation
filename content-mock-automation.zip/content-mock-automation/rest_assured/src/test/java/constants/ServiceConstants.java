package constants;

public class ServiceConstants{
  public static final String BASE_URL="http://localhost:9595";
  public static final String GET_PATH="/human";
  public static final String BASE_PATH="/content";
  public static final String POST_PATH="/hero";
};
