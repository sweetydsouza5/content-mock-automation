package com.sdl.skills;

import com.github.tomakehurst.wiremock.WireMockServer;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

public class ContentMock {
    public static void main(String[] args) {
        WireMockServer server = new WireMockServer(
                options()
                        .port(9595)
                .usingFilesUnderClasspath("wiremock")
        );
        /*server.addStubMapping(stubFor(get("/content/id3").willReturn(
                aResponse().withBody("id3-content")
                .withHeader("Content-Type", "text/plain")
                .withStatus(200)
        )));
*/
        server.start();
    }
}
